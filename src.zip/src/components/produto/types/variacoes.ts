import { supabase } from "../../../../supabaseClient";
import type { ProdutoVariacao, ProdutoVariacaoItem } from "./produtos";
  
export interface VariacaoTipo {
  id: number;
  nome: string;
}

export interface VariacaoValor {
  id: number;
  id_tipo: number;
  valor: string;
}

function isVariantImageTableMissing(error: any): boolean {
  if (!error) {
    return false;
  }

  const code = typeof error.code === "string" ? error.code : "";
  const message = typeof error.message === "string" ? error.message.toLowerCase() : "";
  const details = typeof error.details === "string" ? error.details.toLowerCase() : "";

  return (
    code === "42P01" ||
    code === "PGRST200" ||
    message.includes("produto_variacao_imagem") ||
    details.includes("produto_variacao_imagem") ||
    (message.includes("relation") && message.includes("does not exist"))
  );
}

/* ===========================
   TIPOS
=========================== */

export async function listarTiposVariacao() {
  return await supabase
    .from("variacao_tipo")
    .select("*")
    .order("nome");
}

export async function criarTipoVariacao(
  nome: string
) {
  return await supabase
    .from("variacao_tipo")
    .insert({ nome })
    .select()
    .single();
}

export async function editarTipoVariacao(
  id: number,
  nome: string
) {
  return await supabase
    .from("variacao_tipo")
    .update({ nome })
    .eq("id", id)
    .select()
    .single();
}

export async function excluirTipoVariacao(
  id: number
) {
  return await supabase
    .from("variacao_tipo")
    .delete()
    .eq("id", id);
}

/* ===========================
   VALORES
=========================== */

export async function listarValoresTipo(
  idTipo: number
) {
  return await supabase
    .from("variacao_valor")
    .select("*")
    .eq("id_tipo", idTipo)
    .order("valor");
}

export async function criarValorVariacao(
  idTipo: number,
  valor: string
) {
  return await supabase
    .from("variacao_valor")
    .insert({
      id_tipo: idTipo,
      valor,
    })
    .select()
    .single();
}

export async function editarValorVariacao(
  id: number,
  valor: string
) {
  return await supabase
    .from("variacao_valor")
    .update({ valor })
    .eq("id", id)
    .select()
    .single();
}

export async function excluirValorVariacao(
  id: number
) {
  return await supabase
    .from("variacao_valor")
    .delete()
    .eq("id", id);
}

/* ===========================
   VARIAÇÕES DO PRODUTO
=========================== */

export async function listarVariacoesProduto(
  idProduto: number
) {
  const { data, error } = await supabase
    .from("produto_variacao")
    .select(`
      id,
      id_produto,

      produto_variacao_item(
        id,
        id_valor,

        preco,
        estoque,
        sku,
        ativo,
        imagem_principal,

        variacao_valor(
          id,
          valor,

          variacao_tipo(
            id,
            nome
          )
        )
      )
    `)
    .eq("id_produto", idProduto);

  if (error || !data) {
    return {
      data: null,
      error,
    };
  }

  const variacaoIds = data.map((variacao: any) => variacao.id).filter(Boolean);

  if (variacaoIds.length === 0) {
    return {
      data,
      error: null,
    };
  }

  const { data: links, error: linksError } = await supabase
    .from("produto_variacao_imagem")
    .select("id,id_variacao,id_imagem")
    .in("id_variacao", variacaoIds);

  const linksByVariationId = new Map<number, any[]>();

  if (!linksError && links) {
    for (const link of links) {
      const existing = linksByVariationId.get(link.id_variacao) ?? [];
      existing.push(link);
      linksByVariationId.set(link.id_variacao, existing);
    }
  }

  const merged = data.map((variacao: any) => ({
    ...variacao,
    produto_variacao_imagem: linksByVariationId.get(variacao.id) ?? [],
  }));

  return {
    data: merged,
    error: isVariantImageTableMissing(linksError) ? null : error ?? linksError,
  };
}

export async function criarVariacaoProduto(
  idProduto: number,
) {
  return await supabase
    .from("produto_variacao")
    .insert({
      id_produto: idProduto,
    })
    .select()
    .single();
}

export async function editarVariacaoProduto(
  id: number,
  dados: Partial<ProdutoVariacao>
) {
  return await supabase
    .from("produto_variacao")
    .update(dados)
    .eq("id", id)
    .select()
    .single();
}

export async function excluirVariacaoProduto(
  id: number
) {
  return await supabase
    .from("produto_variacao")
    .delete()
    .eq("id", id);
}

/* ===========================
   ITENS DA VARIAÇÃO
=========================== */


export async function adicionarItemVariacao(
  idVariacao: number,
  idValor: number,
  sku: string = "",
  preco: number = 0,
  estoque: number = 0
) {
  return await supabase
    .from("produto_variacao_item")
    .insert({
      id_variacao: idVariacao,
      id_valor: idValor,
      sku,
      preco,
      estoque,
      ativo: true,
    });
}

export interface VariacaoTipoCompleta {
  id: number;
  nome: string;

  variacao_valor: VariacaoValor[];
}

export async function listarTiposVariacaoCompleto() {
  return await supabase
    .from("variacao_tipo")
    .select(`
      *,
      variacao_valor (
        *
      )
    `)
    .order("nome");
}

export async function buscarTipoVariacao(
  id: number
) {
  return await supabase
    .from("variacao_tipo")
    .select(`
      *,
      variacao_valor (
        *
      )
    `)
    .eq("id", id)
    .single();
}

export async function salvarValoresTipo(
  idTipo: number,
  valores: string[]
) {
  const registros = valores.map((valor) => ({
    id_tipo: idTipo,
    valor,
  }));

  return await supabase
    .from("variacao_valor")
    .insert(registros);
}

async function atualizarItemVariacaoPelaApi(
  idItem: number,
  dados: Record<string, unknown>
): Promise<{ data?: unknown; updatedCount?: number }> {
  const { data: sessionData, error: sessionError } =
    await supabase.auth.getSession();
  const accessToken = sessionData.session?.access_token;

  if (sessionError || !accessToken) {
    throw new Error("Sessão inválida. Faça login novamente.");
  }

  const response = await fetch(`/api/admin/produto-variacao-item/${idItem}/`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify(dados),
  });
  const result = await response.json().catch(() => null) as {
    data?: unknown;
    error?: string;
  } | null;

  if (!response.ok) {
    throw new Error(result?.error ?? "Falha ao salvar variação.");
  }

  if (!result?.data) {
    throw new Error("O servidor não confirmou a atualização da variação.");
  }

  return result;
}

export async function salvarItemVariacao(
  idItem: number,
  dados: {
    preco: number;
    custo_fornecedor?: number | null;
    estoque: number;
    sku?: string;
    ativo: boolean;
    imagem_principal?: string | null;
  }
) {
  const result = await atualizarItemVariacaoPelaApi(idItem, dados);
  return result.data;
}

export async function aplicarPrecoATodasVariacoes(
  itemId: number,
  produtoId: number,
  preco: number
): Promise<number> {
  const result = await atualizarItemVariacaoPelaApi(itemId, {
    preco,
    produto_id: produtoId,
    aplicar_em_todas: true,
  });

  if (!result.updatedCount) {
    throw new Error("O servidor não confirmou a atualização das variações.");
  }

  return result.updatedCount;
}

export async function salvarStatusVariacao(
  idVariacao: number,
  ativo: boolean
) {
  return await supabase
    .from("produto_variacao_item")
    .update({ ativo })
    .eq("id_variacao", idVariacao);
}

export async function excluirVariacoesProduto(
  idProduto: number
) {
  return await supabase
    .from("produto_variacao")
    .delete()
    .eq("id_produto", idProduto);
}

export async function listarTiposProduto(
  idProduto: number
) {
  return await supabase
    .from("produto_variacao_tipo")
    .select("id_tipo")
    .eq("id_produto", idProduto);
}

export async function adicionarTipoProduto(
  idProduto: number,
  idTipo: number
) {
  return await supabase
    .from("produto_variacao_tipo")
    .insert({
      id_produto: idProduto,
      id_tipo: idTipo,
    });
}

export async function removerTipoProduto(
  idProduto: number,
  idTipo: number
) {
  return await supabase
    .from("produto_variacao_tipo")
    .delete()
    .eq("id_produto", idProduto)
    .eq("id_tipo", idTipo);
}

export async function criarItensVariacao(
  idVariacao: number,
  idsValores: number[]
) {
  const registros = idsValores.map((idValor) => ({
    id_variacao: idVariacao,
    id_valor: idValor,
    preco: 0,
    estoque: 0,
    ativo: true,
  }));

  return await supabase
    .from("produto_variacao_item")
    .insert(registros);
}

