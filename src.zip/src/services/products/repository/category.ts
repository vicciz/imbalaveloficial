import "server-only";

import { createClient } from "@supabase/supabase-js";

interface IdRow {
  id: number;
}

function normalizeName(name: string, fallback: string): string {
  const trimmed = name.trim();
  return trimmed.length > 0 ? trimmed : fallback;
}

function errorMessage(error: unknown, context: string): string {
  if (error instanceof Error) {
    return `${context}: ${error.message}`;
  }

  if (typeof error === "object" && error !== null) {
    const databaseError = error as {
      message?: unknown;
      code?: unknown;
      details?: unknown;
      hint?: unknown;
    };
    const parts = [
      databaseError.message,
      typeof databaseError.code === "string" ? `code ${databaseError.code}` : undefined,
      databaseError.details,
      databaseError.hint,
    ].filter((part): part is string => typeof part === "string" && part.length > 0);

    if (parts.length > 0) {
      return `${context}: ${parts.join(" | ")}`;
    }
  }

  return `${context}: Erro desconhecido`;
}

function createCategoryClient() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    throw new Error("Configuração server-side do Supabase ausente.");
  }

  return createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
  });
}

export async function getOrCreateCategoryId(name: string): Promise<number> {
  const category = normalizeName(name, "Sem categoria");
  const supabaseAdmin = createCategoryClient();

  const { data: existing, error: selectError } = await supabaseAdmin
    .from("categorias")
    .select("id")
    .ilike("nome", category)
    .maybeSingle<IdRow>();

  if (selectError) {
    throw new Error(errorMessage(selectError, "Falha ao buscar categoria"));
  }

  if (existing) {
    return existing.id;
  }

  const { data: created, error: createError } = await supabaseAdmin
    .from("categorias")
    .insert({ nome: category })
    .select("id")
    .single<IdRow>();

  if (createError?.code === "23505") {
    const { data: concurrentCategory, error: concurrentLookupError } =
      await supabaseAdmin
        .from("categorias")
        .select("id")
        .ilike("nome", category)
        .maybeSingle<IdRow>();

    if (concurrentLookupError) {
      throw new Error(
        errorMessage(concurrentLookupError, "Falha ao buscar categoria criada em paralelo")
      );
    }

    if (concurrentCategory) {
      return concurrentCategory.id;
    }
  }

  if (createError) {
    throw new Error(errorMessage(createError, "Falha ao criar categoria"));
  }

  if (!created) {
    throw new Error("Falha ao criar categoria: Supabase não retornou o ID.");
  }

  return created.id;
}
