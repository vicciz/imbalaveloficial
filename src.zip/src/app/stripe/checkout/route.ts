import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { buscarProduto } from '@/src/components/produto/types/produtos';
import { variantImageService } from '@/src/services/products/services/VariantImageService';
import { supabase } from '@/supabaseClient';
import { calcularFreteProduto } from '@/src/services/frete/calcularFrete';
import { getUsdBrlRate } from '@/src/services/cambio/usdBrl';

type VariacaoSelecionada = {
  id?: number | string;
  sku?: string;
  preco?: number | string;
  produto_variacao_imagem?: Array<{
    id?: number;
    id_variacao?: number;
    id_imagem?: number;
  }>;
  produto_variacao_item?: Array<{
    id_valor?: number | null;
    variacao_valor?: {
      valor?: string;
      variacao_tipo?: {
        nome?: string;
      };
    };
  }>;
};

function getPublicImageUrl(image?: string | null) {
  if (!image) return null;
  if (image.startsWith('http')) return image;
  if (!supabase) return null;

  const { data } = supabase.storage.from('produtos').getPublicUrl(image);
  return data?.publicUrl ?? null;
}

function extrairAtributosVariacao(
  variacaoSelecionada?: VariacaoSelecionada | null
) {
  const itens = variacaoSelecionada?.produto_variacao_item ?? [];

  return itens
    .map((item) => {
      const tipo = item.variacao_valor?.variacao_tipo?.nome?.trim();
      const valor = item.variacao_valor?.valor?.trim();

      if (!tipo || !valor) return null;

      return { tipo, valor };
    })
    .filter(Boolean) as Array<{ tipo: string; valor: string }>;
}

function obterAtributo(
  atributos: Array<{ tipo: string; valor: string }>,
  nome: string
) {
  const chave = nome.trim().toLowerCase();

  return (
    atributos.find(
      (atributo) =>
        atributo.tipo.trim().toLowerCase() === chave
    )?.valor ?? ''
  );
}

export async function POST(request: NextRequest) {
  try {
    const {
      id,
      quantidade,
      variacaoSelecionada,
      userId,
      cepDestino,
    } = await request.json();

    if (!id || typeof id !== 'number') {
      return NextResponse.json({ error: 'ID do produto inválido' }, { status: 400 });
    }

    // Log para debug em produção
    console.log('NODE_ENV:', process.env.NODE_ENV);
    console.log('VERCEL_ENV:', process.env.VERCEL_ENV);
    console.log('STRIPE_SECRET_KEY presente:', !!process.env.STRIPE_SECRET_KEY);
    console.log('NEXT_PUBLIC_APP_URL:', process.env.NEXT_PUBLIC_APP_URL);

    const stripeKey = process.env.STRIPE_SECRET_KEY?.trim();
    if (!stripeKey) {
      console.error('STRIPE_SECRET_KEY não configurada no ambiente. Verifique se a variável existe em Production no Vercel.');
      return NextResponse.json({
        error: 'Configuração de pagamento não encontrada',
        details: 'STRIPE_SECRET_KEY não configurada'
      }, { status: 500 });
    }

    const stripe = new Stripe(stripeKey, {
      apiVersion: "2026-04-22.dahlia",
    });

    const { data: produto, error } = await buscarProduto(id);

    if (error || !produto) {
      throw new Error('Produto não encontrado');
    }

    const quantidadeSelecionada = Math.max(
      1,
      Math.floor(Number(quantidade) || 1)
    );

    let variacaoReal: any = null;

    if (variacaoSelecionada?.id) {
      const { data: variacaoBanco, error: variacaoError } = await supabase
        .from('produto_variacao')
        .select(`
          id,
          sku,
          preco,
          produto_variacao_item (
            id,
            sku,
            preco,
            estoque,
            ativo,
            fornecedor_sku,
            id_valor,
            variacao_valor (
              valor,
              variacao_tipo (nome)
            )
          )
        `)
        .eq('id', Number(variacaoSelecionada.id))
        .eq('id_produto', id)
        .maybeSingle();

      if (variacaoError) {
        throw new Error('Não foi possível validar a variação selecionada.');
      }

      variacaoReal = variacaoBanco;
    }

    const itemVariacaoReal =
      variacaoReal?.produto_variacao_item?.find((item: any) => item.ativo !== false) ??
      variacaoSelecionada?.item ??
      null;

    const preco = Number(
      itemVariacaoReal?.preco ??
      variacaoReal?.preco ??
      variacaoSelecionada?.preco ??
      produto.preco ??
      0
    );
    if (Number.isNaN(preco) || preco <= 0) {
      throw new Error('Preço do produto inválido');
    }

    const cepDestinoNormalizado = String(cepDestino ?? "").replace(/\D/g, "");
    if (cepDestinoNormalizado.length !== 8) {
      throw new Error("Informe um CEP válido para calcular o frete antes de finalizar a compra.");
    }

    const variantId =
      itemVariacaoReal?.fornecedor_sku ??
      variacaoSelecionada?.item?.fornecedor_sku ??
      variacaoSelecionada?.fornecedor_sku ??
      null;

    const cotacoesFrete = await calcularFreteProduto({
      product: produto,
      variantId: variantId ? String(variantId) : null,
      variantSku: itemVariacaoReal?.sku ?? variacaoReal?.sku ?? variacaoSelecionada?.sku ?? null,
      destinationCep: cepDestinoNormalizado,
      quantity: quantidadeSelecionada,
      productPrice: preco,
    });

    if (!cotacoesFrete.length) {
      throw new Error("Nenhuma modalidade de frete disponível para este CEP.");
    }

    const freteEscolhido = cotacoesFrete[0];

    let freteBRL = freteEscolhido.price;

    if (freteEscolhido.currency === "USD") {
      const usdBrlRate = await getUsdBrlRate();
      freteBRL = Number((freteEscolhido.price * usdBrlRate.rate).toFixed(2));
    }

    if (!Number.isFinite(freteBRL) || freteBRL < 0) {
      throw new Error("Valor de frete inválido.");
    }

    const atributos = extrairAtributosVariacao(
      variacaoSelecionada as VariacaoSelecionada | null
    );

    const cor = obterAtributo(atributos, 'cor');
    const modelo = obterAtributo(atributos, 'modelo');
    const voltagem = obterAtributo(atributos, 'voltagem');

    const resumoVariacao = [
      cor,
      modelo,
      voltagem,
    ].filter(Boolean);

    const descricaoVariacao = resumoVariacao.length
      ? `${produto.nome} • ${resumoVariacao.join(' • ')}`
      : produto.nome;

    const selectedImage = variantImageService.getPrimaryImage(
      produto.produto_imagem ?? [],
      variacaoSelecionada as VariacaoSelecionada | null
    );

    const imageUrl = selectedImage?.caminho
      ? getPublicImageUrl(selectedImage.caminho)
      : null;


    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      metadata: {
        produto_id: String(id ?? ''),
        variacao_id: String(variacaoSelecionada?.id ?? ''),
        sku: String(itemVariacaoReal?.sku ?? variacaoReal?.sku ?? variacaoSelecionada?.sku ?? ''),
        quantidade: String(quantidadeSelecionada),
        cor: String(cor ?? ''),
        modelo: String(modelo ?? ''),
        voltagem: String(voltagem ?? ''),
        usuario_id: String(userId ?? ''),
        cep_destino: cepDestinoNormalizado,
        frete_provedor: freteEscolhido.provider,
        frete_servico: freteEscolhido.serviceName,
        frete_origem_pais: freteEscolhido.originCountryCode,
        frete_valor_brl: freteBRL.toFixed(2),
      },
      line_items: [
        {
          price_data: {
            currency: 'brl',
            unit_amount: Math.round(preco * 100),
            product_data: {
              name: produto.nome || 'Produto Imbalável',
              description: descricaoVariacao,
              images: imageUrl ? [imageUrl] : undefined,
            },
          },
          quantity: quantidadeSelecionada,
        },
        ...(freteBRL > 0
          ? [{
              price_data: {
                currency: 'brl',
                unit_amount: Math.round(freteBRL * 100),
                product_data: {
                  name: "Frete",
                  description: "Frete de entrega",
                },
              },
              quantity: 1,
            }]
          : []),
      ],
      mode: 'payment',
      success_url: `${process.env.NEXT_PUBLIC_APP_URL ?? 'https://www.imbalavel.com.br'}/sucesso`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL ?? 'https://www.imbalavel.com.br'}/cancelado`,
    });

    return NextResponse.json({ url: session.url });
  } catch (error) {
    console.error('Erro ao criar sessão de checkout:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}