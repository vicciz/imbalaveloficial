"use client";

import Image from "next/image";
import Link from "next/link";

import type { Produto } from "@/src/components/produto/types/produtos";

type Props = {
  produto: Produto;
};
function obterMenorPreco(produto: Produto) {
  const itens =
    produto.produto_variacao?.flatMap(
      (v: any) => v.produto_variacao_item ?? []
    ) ?? [];

  if (!itens.length) return null;

  return Math.min(
    ...itens.map((item: any) => Number(item.preco))
  );
}

export default function HomeProductCard({
  produto,
}: Props) {
  const menorPreco = obterMenorPreco(produto);

  return (
    <Link
      href={`/produto/${produto.id}`}
className="
  group
  w-[210px]
  flex-shrink-0
  overflow-hidden
  rounded-xl
  border
  border-zinc-200
  bg-white
  transition-all
  duration-300
  hover:-translate-y-1
  hover:border-violet-200
  hover:shadow-xl
">
     <div
        className="
  
    flex
    h-56
    items-center
    justify-center
    border-b
    border-zinc-100
    bg-white
    p-5
  "
>
        <Image
          src={produto.image || "/placeholder.png"}
          alt={produto.nome ?? "Produto"}
          width={190}
          height={190}
          className="
            h-auto
            max-h-[180px]
            w-auto
            object-contain
            transition-all
            duration-500
           group-hover:scale-[1.08]
          "
          />
      </div>

      <div className="pb-4">
      <h3
        className="
          line-clamp-2
          h-10
          text-sm
          text-zinc-700
        "
      >
          {produto.nome}
        </h3>

        <div className="mt-3"><div className="mb-2">

    <span
        className="
            rounded-md
            bg-green-100
            px-2
            py-1
            text-xs
            font-semibold
            text-green-700
        "
    >
        20% OFF
    </span>

</div>
  <div className="mt-3">
    <span className="block text-xs font-medium uppercase tracking-wide text-zinc-500">
      A partir de
    </span>

    <span
      className="
        text-[34px]
        font-light
        tracking-tight
        transition-colors
        duration-300
        group-hover:text-violet-700
      "
    >
     {menorPreco !== null
  ? menorPreco.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    })
  : "Indisponível"}
    </span>

    <p className="mt-1 text-xs text-zinc-500">
      em até 10x sem juros
    </p>
  </div>
        </div>

       <p
        className="
          mt-3
          text-sm
          font-semibold
          text-green-600
      transition-all
      duration-300
      group-hover:translate-x-1
        "
      >
          Frete grátis
        </p>

        <div
  className="
    mt-4
    opacity-0
    translate-y-2
    transition-all
    duration-300
    group-hover:translate-y-0
    group-hover:opacity-100
  "
>
  <button
    className="
      w-full
      rounded-lg
      bg-violet-600
      py-2
      text-sm
      font-semibold
      text-white
      transition
      hover:bg-violet-700
    "
  >
    Ver produto
  </button>
</div>
      </div>
    </Link>
  );
}